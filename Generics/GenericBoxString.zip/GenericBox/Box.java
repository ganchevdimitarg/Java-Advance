package Generics.GenericBox;

public class Box<T> {
    private T text;

    public void setText(T text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return String.format("%s: %s", text.getClass(), this.text );
    }
}
