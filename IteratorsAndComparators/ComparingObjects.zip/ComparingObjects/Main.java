package IteratorsAndComparators.ComparingObjects;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] tokens = scanner.nextLine().split("\\s+");

        List<Person> people = new ArrayList<>();

        while (!"END".equals(tokens[0])) {

            Person person = new Person(tokens[0], Integer.parseInt(tokens[1]), tokens[2]);

            people.add(person);

            tokens = scanner.nextLine().split("\\s+");
        }

        int n = Integer.parseInt(scanner.nextLine());

        Person comparaPerson = people.get(n - 1);

        int e = (int)people.stream().filter(p -> p.compareTo(comparaPerson) == 0).count();

        if (e == 1){
            System.out.println("No matches");
        } else {
            System.out.printf("%d %d %d", e, people.size() - e, people.size());
        }

    }
}
